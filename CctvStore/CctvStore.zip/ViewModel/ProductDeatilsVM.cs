﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CctvStore.ViewModel
{
    public class ProductDeatilsVM
    {
        //public ProductDeatilsVM()
        //{
        //    Specifications = new Specifications();
        //    SpCameras = new SpCameras();
        //    SpImages=new SpImages();
        //  //  JobQuestionAnswers = new List<JobQuestionAnswer>();
        //}
        //public Specification Specifications { get; set; }
        //public SpCamera SpCameras { get; set; }
        //public SpImage SpImages { get; set; }
        
        
        //public List<JobQuestionAnswer> JobQuestionAnswers { get; set; }
        //public <Specification> Specification { get; set; }
        //public IEnumerable<SpCamera> SpCamera { get; set; }
        //public IEnumerable<SpImage> SpImage { get; set; }
        //public IEnumerable<SpInterface> SpInterface { get; set; }
        //public IEnumerable<SpGeneral> SpGeneral { get; set; }
    }



      

}